package it.unibo.bluff.model

enum Suit:
  case Clubs, Diamonds, Hearts, Spades
